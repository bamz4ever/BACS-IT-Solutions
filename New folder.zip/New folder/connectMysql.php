<?php
$servername = "localhost";
$username = "root";
$password = "Password1";
$Db ="mysql";

// Create connection
//$conn = new mysqli($servername, $username, $password, $Db);
$conn = mysqli_connect($servername, $username, $password, $Db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully<br>";
?>