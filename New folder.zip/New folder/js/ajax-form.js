package com.mahal.assingment2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;

import static com.mahal.assingment2.R.id.content;
import static com.mahal.assingment2.R.id.resultsText;
import static com.mahal.assingment2.R.id.spinner;

public class mainpage extends AppCompatActivity {
    private EditText editText1,
            editText2;

    private Spinner spinner;
    private TextView resultsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);
       editText1 = (EditText) findViewById(R.id.editText1);
      editText2 = (EditText)findViewById(R.id.editText2);
       spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Service, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        resultsText = (TextView) findViewById(R.id.resultsText);

        TextWatcher textWatcher = new TextWatcher() {
            public void afterTextChanged(Editable s) {
                calculateResult();
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after){}
            public void onTextChanged(CharSequence s, int start, int before, int count){}
        };
        editText1.addTextChangedListener(textWatcher);
        editText2.addTextChangedListener(textWatcher);
    }
    private void calculateResult() throws NumberFormatException {
      
        Editable editableValue1 = editText1.getText(),
                editableValue2 = editText2.getText();

        double value1 = 0.0;
           int value2 = 0;
             double result;


        if (editableValue1 != null)
            value1 = Double.parseDouble(editableValue1.toString());

        if (editableValue2 != null)
            value2 = Integer.parseInt(editableValue2.toString());

        // Calculates the result
        result = value1 / value2;

       
        resultsText.setText(result.toString());
    }

}
